# QuantumEnergyOS V.02 — Perfil archiso

## Descripción

Este directorio contiene el perfil completo de **archiso** para construir la imagen ISO booteable de **QuantumEnergyOS V.02**, basada en Arch Linux con Wayland/Sway.

## Requisitos

- **Sistema operativo**: Arch Linux (nativo o máquina virtual)
- **Paquete**: `archiso` (versión 88 o superior)
- **Espacio en disco**: mínimo 20 GB libres
- **RAM**: mínimo 4 GB
- **Conexión a internet**: requerida para descargar paquetes

## Instalación de dependencias

```bash
sudo pacman -S archiso
```

## Construcción de la ISO

### Método 1 — Script automático (recomendado)

```bash
sudo bash BUILD.sh
```

La ISO se guardará en `~/ISOs/QuantumEnergyOS-*.iso`.

### Método 2 — Comando manual

```bash
sudo mkarchiso -v -w /tmp/qeos-work -o ~/ISOs /ruta/a/este/directorio
```

## Estructura del perfil

```
qeos-profile/
├── profiledef.sh              # Configuración principal de la ISO
├── packages.x86_64            # Lista de paquetes a instalar
├── pacman.conf                # Configuración de repositorios
├── BUILD.sh                   # Script de construcción automático
├── grub/
│   └── grub.cfg               # Configuración del bootloader GRUB (UEFI)
├── syslinux/
│   └── syslinux.cfg           # Configuración del bootloader Syslinux (BIOS)
├── efiboot/
│   └── loader/loader.conf     # Configuración systemd-boot
└── airootfs/
    ├── root/
    │   └── customize_airootfs.sh  # Script de personalización del sistema
    └── opt/QuantumEnergyOS/       # Archivos del proyecto QEOS
        ├── server.py
        ├── core.py
        ├── requirements.txt
        ├── api/
        │   ├── server.py
        │   └── core.py
        └── kernel/
            └── quantum_photonic/
                └── photonic_core.py
```

## Características de la ISO

- **Base**: Arch Linux rolling release
- **Compositor**: Sway (Wayland)
- **Usuario**: `quantum` (contraseña: `quantum`)
- **Idioma**: Español México (es_MX.UTF-8)
- **Zona horaria**: America/Tijuana
- **Comandos especiales**: `qeos`, `qsh`
- **Servicios**: QuantumEnergyOS daemon, NetworkManager, SSH

## Notas

- El proceso de construcción puede tomar entre 30 y 60 minutos dependiendo de la velocidad de internet y del hardware.
- La ISO resultante tendrá un tamaño aproximado de 1.5-2.5 GB.
- Para probar la ISO, se puede usar VirtualBox, VMware, QEMU o grabarla en un USB con `dd` o Balena Etcher.
