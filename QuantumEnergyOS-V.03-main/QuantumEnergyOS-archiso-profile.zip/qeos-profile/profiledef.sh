#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════
#  archiso/profiledef.sh — Perfil de construcción ISO QuantumEnergyOS
#  Basado en Arch Linux archiso 88 + Wayland/Sway
# ═══════════════════════════════════════════════════════════════════════
iso_name="QuantumEnergyOS"
iso_label="QEOS_V02"
iso_publisher="Giovanny Corpus Bernal <github.com/GioCorpus>"
iso_application="QuantumEnergyOS V.02 — Desde Mexicali para el mundo"
iso_version="0.2.0"
install_dir="arch"
buildmodes=('iso')
bootmodes=('bios.syslinux' 'uefi.grub')
arch="x86_64"
pacman_conf="${profile}/pacman.conf"
airootfs_image_type="squashfs"
airootfs_image_tool_options=('-comp' 'xz' '-Xbcj' 'x86' '-b' '1M' '-Xdict-size' '1M')
file_permissions=(
  ["/etc/shadow"]="0:0:400"
  ["/root"]="0:0:750"
  ["/root/customize_airootfs.sh"]="0:0:755"
  ["/usr/local/bin/qeos"]="0:0:755"
  ["/usr/local/bin/qsh"]="0:0:755"
)
