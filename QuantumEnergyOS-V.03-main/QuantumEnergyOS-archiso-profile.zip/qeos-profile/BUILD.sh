#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════
#  BUILD.sh — Script de construcción de ISO QuantumEnergyOS V.02
#  Ejecutar en Arch Linux con archiso instalado
#  Uso: sudo bash BUILD.sh
# ═══════════════════════════════════════════════════════════════════════
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK_DIR="/tmp/qeos-work"
OUT_DIR="${HOME}/ISOs"

# Verificar que se ejecuta como root
if [[ $EUID -ne 0 ]]; then
    echo "ERROR: Este script debe ejecutarse como root (sudo bash BUILD.sh)"
    exit 1
fi

# Verificar dependencias
echo "=== Verificando dependencias ==="
for cmd in mkarchiso pacman; do
    if ! command -v "$cmd" &>/dev/null; then
        echo "ERROR: '$cmd' no encontrado. Instalar con: sudo pacman -S archiso"
        exit 1
    fi
done
echo "✓ Dependencias OK"

# Crear directorios
mkdir -p "$WORK_DIR" "$OUT_DIR"

# Limpiar trabajo anterior
echo "=== Limpiando trabajo anterior ==="
rm -rf "$WORK_DIR"
mkdir -p "$WORK_DIR"

# Construir la ISO
echo "=== Construyendo QuantumEnergyOS V.02 ISO ==="
echo "    Perfil: $SCRIPT_DIR"
echo "    Trabajo: $WORK_DIR"
echo "    Salida: $OUT_DIR"
echo ""
echo "⚡ Iniciando mkarchiso... (esto puede tomar 30-60 minutos)"
echo ""

mkarchiso -v -w "$WORK_DIR" -o "$OUT_DIR" "$SCRIPT_DIR"

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "  ✅ ISO construida exitosamente!"
echo "  📁 Ubicación: $OUT_DIR"
ls -lh "$OUT_DIR"/*.iso 2>/dev/null || echo "  (buscar archivo .iso en $OUT_DIR)"
echo "═══════════════════════════════════════════════════════════════"
