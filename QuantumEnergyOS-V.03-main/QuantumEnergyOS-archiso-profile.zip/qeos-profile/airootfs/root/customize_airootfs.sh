#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════
#  customize_airootfs.sh — Personalización del sistema QuantumEnergyOS
#  Se ejecuta dentro del chroot durante la construcción de la ISO
# ═══════════════════════════════════════════════════════════════════════
set -e

echo "⚡ [QEOS] Iniciando personalización del sistema..."

# ── 1. Configurar locale y timezone ──────────────────────────────────
echo "LANG=es_MX.UTF-8" > /etc/locale.conf
echo "es_MX.UTF-8 UTF-8" >> /etc/locale.gen
echo "en_US.UTF-8 UTF-8" >> /etc/locale.gen
locale-gen
ln -sf /usr/share/zoneinfo/America/Tijuana /etc/localtime
echo "QuantumEnergyOS" > /etc/hostname

# ── 2. Configurar usuario quantum ────────────────────────────────────
useradd -m -G wheel,audio,video,network -s /bin/bash quantum 2>/dev/null || true
echo "quantum:quantum" | chpasswd
echo "root:quantum" | chpasswd
echo "%wheel ALL=(ALL) NOPASSWD: ALL" >> /etc/sudoers

# ── 3. Instalar dependencias Python en venv ──────────────────────────
VENV_DIR="/opt/QuantumEnergyOS/venv"
mkdir -p /opt/QuantumEnergyOS
python3 -m venv "${VENV_DIR}"
"${VENV_DIR}/bin/pip" install --upgrade pip --quiet
"${VENV_DIR}/bin/pip" install --quiet \
    "qiskit==1.4.2" \
    "qiskit-aer==0.16.0" \
    "flask" \
    "flask-cors" \
    "pydantic>=2.0" \
    "numpy>=2.0" \
    "scipy" \
    "matplotlib" \
    "certifi>=2026.1.4" \
    "cryptography>=46.0.5" \
    "requests>=2.32.4" \
    "setuptools>=78.1.1" \
    "uvicorn" \
    "fastapi" || echo "[QEOS] Algunos paquetes Python no disponibles — instalar manualmente"

echo "[QEOS] Python packages instalados"

# ── 4. Comando global qeos ───────────────────────────────────────────
cat > /usr/local/bin/qeos << 'QEOS_BIN'
#!/usr/bin/env bash
# QuantumEnergyOS launcher
source /opt/QuantumEnergyOS/venv/bin/activate 2>/dev/null || true
cd /opt/QuantumEnergyOS
case "${1:-}" in
    start)
        echo "⚡ Iniciando QuantumEnergyOS API..."
        uvicorn api.server:app --host 0.0.0.0 --port 8000 &
        echo "Dashboard: http://localhost:8000"
        ;;
    stop)
        pkill -f "uvicorn api.server" || echo "No estaba corriendo"
        ;;
    status)
        curl -s http://localhost:8000/api/v1/status | python3 -m json.tool
        ;;
    grid)
        python3 -c "
from api.core import simular_grid
import json
r = simular_grid(6, 1024, 0.5, 0.3)
print(json.dumps(r, indent=2, ensure_ascii=False))
"
        ;;
    fusion)
        python3 -c "
from api.core import simular_fusion
import json
r = simular_fusion(65.0, 1.0, 1.0, 4)
print(json.dumps(r, indent=2, ensure_ascii=False))
"
        ;;
    notebook)
        jupyter notebook /opt/QuantumEnergyOS/notebooks/demo_energy.ipynb
        ;;
    *)
        echo "Uso: qeos [start|stop|status|grid|fusion|notebook]"
        ;;
esac
QEOS_BIN
chmod +x /usr/local/bin/qeos

# ── 5. Quantum Shell shortcut ─────────────────────────────────────────
cat > /usr/local/bin/qsh << 'QSH_BIN'
#!/usr/bin/env bash
# Quantum Shell — REPL interactivo de QuantumEnergyOS
source /opt/QuantumEnergyOS/venv/bin/activate 2>/dev/null || true
echo "⚡ QuantumEnergyOS Quantum Shell"
echo "   Comandos: grid(), fusion(), braiding(), cooling()"
python3 -i -c "
try:
    from api.core import simular_grid as grid, simular_fusion as fusion
    print('Módulos cargados. Prueba: grid(4, 1024, 0.5, 0.3)')
except ImportError:
    print('Módulos no disponibles. Instala las dependencias con: qeos start')
"
QSH_BIN
chmod +x /usr/local/bin/qsh

# ── 6. Configurar Sway (Wayland compositor) ───────────────────────────
mkdir -p /etc/skel/.config/sway
cat > /etc/skel/.config/sway/config << 'SWAY_CONF'
# QuantumEnergyOS — Sway config (Wayland)
# Tema: desierto de Mexicali + partículas cuánticas azules

set $mod Mod4

# Fondo de pantalla
output * background #0a0a1a solid_color

# Colores cuánticos
set $quantum_blue   #00ffff
set $desert_orange  #ff6b00
set $deep_black     #0a0a1a

# Terminal
bindsym $mod+Return exec foot
bindsym $mod+d      exec wofi --show run
bindsym $mod+q      kill
bindsym $mod+Shift+e exec swaynag -t warning -m '¿Cerrar sesión?' -B 'Sí' 'swaymsg exit'

# Movimiento de ventanas
bindsym $mod+h focus left
bindsym $mod+j focus down
bindsym $mod+k focus up
bindsym $mod+l focus right

# Pantalla completa
bindsym $mod+f fullscreen toggle

# Captura de pantalla
bindsym Print exec grim ~/screenshot-$(date +%Y%m%d-%H%M%S).png

# Autostart: lanzar el dashboard al boot
exec_always qeos start
exec_always bash -c "sleep 5 && foot -e bash -c 'echo ⚡ QuantumEnergyOS V.02 listo; bash'"

# Efectos visuales
default_border pixel 2
gaps inner 8
gaps outer 4

client.focused          $quantum_blue $deep_black $quantum_blue $quantum_blue
client.unfocused        #333333 $deep_black #888888 #333333
client.urgent           $desert_orange $deep_black $desert_orange $desert_orange

# Barra de estado
bar {
    position top
    status_command while date +'⚡ QEOS %H:%M:%S  |  Kardashev 0→1  |  Mexicali, BC'; do sleep 1; done
    colors {
        background $deep_black
        statusline $quantum_blue
        focused_workspace $quantum_blue $deep_black $quantum_blue
        inactive_workspace #333333 $deep_black #888888
    }
}
SWAY_CONF

# Copiar config de sway al usuario quantum
mkdir -p /home/quantum/.config/sway
cp /etc/skel/.config/sway/config /home/quantum/.config/sway/config
chown -R quantum:quantum /home/quantum/.config

# ── 7. Servicio systemd para el API ──────────────────────────────────
cat > /etc/systemd/system/qeos-api.service << 'SYSTEMD_UNIT'
[Unit]
Description=QuantumEnergyOS API Server
After=network.target
Wants=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/QuantumEnergyOS
ExecStart=/opt/QuantumEnergyOS/venv/bin/python -m uvicorn api.server:app --host 0.0.0.0 --port 8000
Restart=on-failure
RestartSec=5s
Environment=QEOS_ENV=production
Environment=PYTHONPATH=/opt/QuantumEnergyOS

[Install]
WantedBy=multi-user.target
SYSTEMD_UNIT

# ── 8. Habilitar servicios ────────────────────────────────────────────
systemctl enable NetworkManager
systemctl enable sshd
systemctl enable qeos-api.service 2>/dev/null || true

# ── 9. Configurar autologin en TTY1 con Sway ─────────────────────────
mkdir -p /etc/systemd/system/getty@tty1.service.d
cat > /etc/systemd/system/getty@tty1.service.d/autologin.conf << 'AUTOLOGIN'
[Service]
ExecStart=
ExecStart=-/sbin/agetty --autologin quantum --noclear %I $TERM
AUTOLOGIN

# Agregar inicio automático de Sway al .bash_profile del usuario quantum
cat >> /home/quantum/.bash_profile << 'BASHPROFILE'
# Iniciar Sway automáticamente en TTY1
if [ -z "${WAYLAND_DISPLAY}" ] && [ "${XDG_VTNR}" -eq 1 ]; then
    exec sway
fi
BASHPROFILE
chown quantum:quantum /home/quantum/.bash_profile

# ── 10. MOTD personalizado ────────────────────────────────────────────
cat > /etc/motd << 'MOTD'

  ╔═══════════════════════════════════════════════════════════╗
  ║   ⚡  QuantumEnergyOS V.02  —  Arch Linux + Wayland      ║
  ║   Desde Mexicali, BC — para el mundo entero               ║
  ║   Kardashev 0→1                                           ║
  ╠═══════════════════════════════════════════════════════════╣
  ║  Comandos:                                                ║
  ║    qeos start    — Iniciar API (http://localhost:8000)    ║
  ║    qeos status   — Ver estado del sistema                 ║
  ║    qeos grid     — Simular red eléctrica cuántica         ║
  ║    qeos fusion   — Simular fusión nuclear                 ║
  ║    qsh           — Quantum Shell interactivo              ║
  ╚═══════════════════════════════════════════════════════════╝

MOTD

echo ""
echo "✅ [QEOS] Personalización completada"
echo "   ISO lista para: qeos start → http://localhost:8000"
