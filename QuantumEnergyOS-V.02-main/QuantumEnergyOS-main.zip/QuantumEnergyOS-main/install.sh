#!/bin/bash
# ──────────────────────────────────────────────────────────────────────────────
# install.sh — QuantumEnergyOS Universal Installation Script
# Automatically detects your Linux distribution and installs dependencies
#
# Supported distributions:
#   - Ubuntu and derivatives (Linux Mint, Pop!_OS, Zorin OS, etc.)
#   - Debian and derivatives
#   - Arch Linux and derivatives (Manjaro, EndeavourOS, ArcoLinux, etc.)
#   - Fedora, CentOS, RHEL (via DNF)
#   - openSUSE (via Zypper)
#
# Usage: chmod +x install.sh && ./install.sh
# ──────────────────────────────────────────────────────────────────────────────

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Detect OS function
detect_os() {
    if [[ -f /etc/os-release ]]; then
        source /etc/os-release
        case "$ID" in
            ubuntu|linuxmint|pop|zorin|elementary| KDE_neon)
                echo "ubuntu"
                ;;
            debian|raspbian)
                echo "debian"
                ;;
            arch|manjaro|endeavouros|arcolinux|garuda|archcraft)
                echo "arch"
                ;;
            fedora|rhel|centos|rocky|alma)
                echo "fedora"
                ;;
            opensuse|sles)
                echo "opensuse"
                ;;
            *)
                # Try ID_LIKE for derivatives
                if [[ -n "$ID_LIKE" ]]; then
                    case "$ID_LIKE" in
                        *ubuntu*|*debian*)
                            echo "ubuntu"
                            ;;
                        *arch*|*manjaro*)
                            echo "arch"
                            ;;
                        *fedora*|*rhel*|*centos*)
                            echo "fedora"
                            ;;
                        *opensuse*)
                            echo "opensuse"
                            ;;
                        *)
                            echo "unknown"
                            ;;
                    esac
                else
                    echo "unknown"
                fi
                ;;
        esac
    elif [[ -f /etc/arch-release ]]; then
        echo "arch"
    elif [[ -f /etc/redhat-release ]]; then
        echo "fedora"
    elif [[ -f /etc/debian_version ]]; then
        echo "debian"
    else
        echo "unknown"
    fi
}

echo -e "${CYAN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║     QuantumEnergyOS - Universal Installation Script        ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Detect OS
echo -e "${CYAN}[1/6] Detecting operating system...${NC}"
OS=$(detect_os)

case "$OS" in
    ubuntu)
        echo "Detected: Ubuntu/Debian-based distribution"
        echo ""
        echo "Running Ubuntu installation script..."
        if [[ -f "$(dirname "$0")/install-ubuntu.sh" ]]; then
            bash "$(dirname "$0")/install-ubuntu.sh"
        else
            echo -e "${RED}Error: install-ubuntu.sh not found${NC}"
            exit 1
        fi
        ;;
    debian)
        echo "Detected: Debian-based distribution"
        echo ""
        echo "Running Ubuntu installation script (compatible with Debian)..."
        if [[ -f "$(dirname "$0")/install-ubuntu.sh" ]]; then
            bash "$(dirname "$0")/install-ubuntu.sh"
        else
            echo -e "${RED}Error: install-ubuntu.sh not found${NC}"
            exit 1
        fi
        ;;
    arch)
        echo "Detected: Arch Linux/Manjaro-based distribution"
        echo ""
        echo "Running Arch installation script..."
        if [[ -f "$(dirname "$0")/install-arch.sh" ]]; then
            bash "$(dirname "$0")/install-arch.sh"
        else
            echo -e "${RED}Error: install-arch.sh not found${NC}"
            exit 1
        fi
        ;;
    fedora)
        echo "Detected: Fedora/CentOS/RHEL-based distribution"
        echo ""
        echo -e "${YELLOW}Note: Fedora support coming soon.${NC}"
        echo "Please use the Docker container or manual installation."
        exit 0
        ;;
    opensuse)
        echo "Detected: openSUSE-based distribution"
        echo ""
        echo -e "${YELLOW}Note: openSUSE support coming soon.${NC}"
        echo "Please use the Docker container or manual installation."
        exit 0
        ;;
    *)
        echo -e "${RED}Error: Unsupported operating system detected.${NC}"
        echo ""
        echo "Supported systems:"
        echo "  - Ubuntu and derivatives (Linux Mint, Pop!_OS, Zorin OS)"
        echo "  - Debian and derivatives"
        echo "  - Arch Linux and derivatives (Manjaro, EndeavourOS)"
        echo "  - Fedora/CentOS/RHEL (coming soon)"
        echo "  - openSUSE (coming soon)"
        echo ""
        echo "Alternatively, use Docker:"
        echo "  docker build -t quantumenergyos ."
        echo "  docker run -p 8000:8000 quantumenergyos"
        exit 1
        ;;
esac
