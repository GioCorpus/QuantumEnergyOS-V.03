# QuantumEnergyOS Installation Guide

This document provides installation instructions for QuantumEnergyOS on various Linux distributions.

## Table of Contents

- [Quick Start](#quick-start)
- [Ubuntu & Derivatives](#ubuntu--derivatives)
- [Arch Linux & Derivatives](#arch-linux--derivatives)
- [Docker Installation](#docker-installation)
- [Troubleshooting](#troubleshooting)

---

## Quick Start

The easiest way to install QuantumEnergyOS on any supported Linux distribution:

```bash
# Clone or download QuantumEnergyOS
cd QuantumEnergyOS-main

# Make the universal installer executable
chmod +x install.sh

# Run the installer (auto-detects your OS)
./install.sh
```

---

## Ubuntu & Derivatives

Supported distributions:
- Ubuntu 20.04+, 22.04+, 24.04+
- Linux Mint 20+
- Pop!_OS 20.04+
- Zorin OS 16+
- Elementary OS 6+
- KDE Neon

### Method 1: Automated Script

```bash
chmod +x install-ubuntu.sh
./install-ubuntu.sh
```

### Method 2: Manual Installation

```bash
# Update package lists
sudo apt update && sudo apt upgrade -y

# Install system dependencies
sudo apt install -y \
    python3 \
    python3-pip \
    python3-venv \
    python3-dev \
    build-essential \
    libffi-dev \
    libssl-dev \
    zlib1g-dev \
    libbz2-dev \
    libreadline-dev \
    libsqlite3-dev \
    wget \
    curl \
    git \
    ca-certificates

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install Python dependencies
pip install --upgrade pip
pip install -r requirements-pinned.txt

# Run the application
uvicorn api.server:app --reload
```

---

## Arch Linux & Derivatives

Supported distributions:
- Arch Linux (rolling)
- Manjaro (stable, testing, unstable)
- EndeavourOS
- ArcoLinux
- Garuda Linux
- ArchCraft

### Method 1: Automated Script

```bash
chmod +x install-arch.sh
./install-arch.sh
```

### Method 2: Manual Installation

```bash
# Update system
sudo pacman -Syu

# Install base dependencies
sudo pacman -S --needed \
    python \
    python-pip \
    python-venv \
    base-devel \
    openssl \
    libffi \
    zlib \
    bzip2 \
    readline \
    sqlite \
    wget \
    curl \
    git \
    ca-certificates

# Create virtual environment
python -m venv venv
source venv/bin/activate

# Install Python dependencies
pip install --upgrade pip
pip install -r requirements-pinned.txt

# Run the application
uvicorn api.server:app --reload
```

### Note for Manjaro Users

Manjaro uses PAMAC by default. You can also use:

```bash
pamac install python python-pip base-devel openssl libffi
```

---

## Docker Installation

For containerized deployment on any OS:

```bash
# Build the Docker image
docker build -t quantumenergyos .

# Run the container
docker run -d \
  --name quantumenergyos \
  -p 8000:8000 \
  -e QEOS_JWT_SECRET=$(openssl rand -hex 32) \
  quantumenergyos

# Access the API
curl http://localhost:8000/api/v1/status
```

### Docker Compose

```yaml
version: '3.8'

services:
  quantumenergyos:
    build: .
    ports:
      - "8000:8000"
    environment:
      - QEOS_ENV=production
      - QEOS_JWT_SECRET=your-secret-here
    restart: unless-stopped
```

---

## Troubleshooting

### Python Version Issues

If you need Python 3.11+:

**Ubuntu:**
```bash
sudo apt install python3.11 python3.11-venv python3.11-dev
python3.11 -m venv venv
```

**Arch Linux:**
```bash
# Arch Python is usually up-to-date
# If not, use the AUR:
yay -S python311
```

### Permission Errors

If you encounter permission errors:

```bash
# Don't use sudo with pip
# Instead, use a virtual environment
python3 -m venv venv
source venv/bin/activate
pip install --user package_name
```

### SSL/TLS Errors

If you get SSL certificate errors:

```bash
# Update CA certificates
sudo apt install ca-certificates     # Ubuntu
sudo pacman -S ca-certificates       # Arch
```

### Module Not Found Errors

If Python modules are not found:

```bash
# Ensure virtual environment is activated
source venv/bin/activate

# Reinstall dependencies
pip install -r requirements-pinned.txt
```

---

## System Requirements

- **Python:** 3.11+ (3.10 minimum)
- **RAM:** 4GB minimum, 8GB recommended
- **Disk Space:** 2GB for dependencies
- **Operating System:** Linux (Ubuntu 20.04+, Arch rolling) or Docker

---

## Next Steps

After installation:

1. Activate the virtual environment:
   ```bash
   source venv/bin/activate
   ```

2. Start the API server:
   ```bash
   uvicorn api.server:app --reload --port 8000
   ```

3. Access the API at: http://localhost:8000

4. View API documentation: http://localhost:8000/docs

---

For more information, see:
- [README.md](../README.md)
- [Architecture Documentation](architecture.md)
- [Security Documentation](SECURITY.md)
